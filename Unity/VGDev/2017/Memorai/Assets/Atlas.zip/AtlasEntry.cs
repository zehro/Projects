﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AtlasEntry : MonoBehaviour {

    public GameObject enemy;
    public string enemyName;
    public string description;
    public string designer;
    public bool isUnlocked; // Has no purpose yet

	// Use this for initialization
	
	
	// Update is called once per frame
	void Update () {
		
	}
}
